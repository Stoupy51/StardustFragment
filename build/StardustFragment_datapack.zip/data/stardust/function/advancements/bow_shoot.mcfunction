
#> stardust:advancements/bow_shoot
#
# @executed	as the player & at current position
#
# @within	advancement stardust:technical/bow_shoot
#

# Revoke advancement and reset score
advancement revoke @s only stardust:technical/bow_shoot
scoreboard players set @s stardust.bow_shoot 0

# Set sneaking flag if player is sneaking
scoreboard players set #is_sneaking stardust.data 0
execute if predicate stardust:player/sneaking run scoreboard players set #is_sneaking stardust.data 1

# If Stardust Bow (x2.0), if Awakened Stardust Bow (x3.0), if Ultimate Bow (x4.0)
execute if items entity @s weapon.mainhand *[custom_data~{stardust:{"stardust_bow":true}}] as @n[type=arrow,tag=!stardust.damage_multiplied,nbt={weapon:{components:{"minecraft:custom_data":{stardust:{"stardust_bow":true}}}}}] run function stardust:utils/modify_arrow {hundredfold:200.0}
execute if items entity @s weapon.mainhand *[custom_data~{stardust:{"awakened_stardust_bow":true}}] as @n[type=arrow,tag=!stardust.damage_multiplied,nbt={weapon:{components:{"minecraft:custom_data":{stardust:{"awakened_stardust_bow":true}}}}}] run function stardust:utils/modify_arrow {hundredfold:300.0}
execute if items entity @s weapon.mainhand *[custom_data~{stardust:{"ultimate_bow":true}}] as @n[type=arrow,tag=!stardust.damage_multiplied,nbt={weapon:{components:{"minecraft:custom_data":{stardust:{"ultimate_bow":true}}}}}] run function stardust:utils/modify_arrow {hundredfold:400.0}

