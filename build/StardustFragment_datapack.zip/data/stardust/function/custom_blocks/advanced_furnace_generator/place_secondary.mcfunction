
#> stardust:custom_blocks/advanced_furnace_generator/place_secondary
#
# @executed	at @s
#
# @within	stardust:custom_blocks/advanced_furnace_generator/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add stardust.custom_block
tag @s add stardust.advanced_furnace_generator
tag @s add stardust.vanilla.minecraft_furnace

# Add a custom name
data merge entity @s {"CustomName": {"translate": "stardust.advanced_furnace_generator"}}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="stardust:advanced_furnace_generator"]
data modify entity @s transformation.scale set value [1.002f,1.002f,1.002f]
function stardust:custom_blocks/compute_brightness

# Apply rotation
execute if score #rotation stardust.data matches 1 run data modify entity @s Rotation[0] set value 180.0f
execute if score #rotation stardust.data matches 2 run data modify entity @s Rotation[0] set value 270.0f
execute if score #rotation stardust.data matches 3 run data modify entity @s Rotation[0] set value 0.0f
execute if score #rotation stardust.data matches 4 run data modify entity @s Rotation[0] set value 90.0f

# Energy part
tag @s add energy.send
scoreboard players set @s stardust.energy_rate 20
scoreboard players set @s energy.max_storage 1600
scoreboard players operation @s energy.transfer_rate = @s energy.max_storage
scoreboard players add @s energy.storage 0
scoreboard players add @s energy.change_rate 0
function energy:v1/api/init_machine

# ItemIO compatibility
tag @s add itemio.container
tag @s add itemio.container.hopper
data modify entity @s item.components."minecraft:custom_data".itemio.ioconfig set value [{"Slot":1,"mode":"input","allowed_side":{"north":true,"south":true,"east":true,"west":true,"top":true}}]
function #itemio:calls/container/init

# Make the block rotatable by wrench
tag @s add simplenergy.rotatable
# Add tag for loop every second
tag @s add stardust.second
scoreboard players add #second_entities stardust.data 1

