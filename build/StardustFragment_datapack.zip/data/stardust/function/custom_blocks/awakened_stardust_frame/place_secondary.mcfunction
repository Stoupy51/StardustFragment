
#> stardust:custom_blocks/awakened_stardust_frame/place_secondary
#
# @executed	at @s
#
# @within	stardust:custom_blocks/awakened_stardust_frame/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add stardust.custom_block
tag @s add stardust.awakened_stardust_frame
tag @s add stardust.vanilla.minecraft_redstone_block

# Add a custom name
data merge entity @s {"CustomName": {"translate": "stardust.awakened_stardust_frame","fallback": "Awakened Stardust Frame"}}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="stardust:awakened_stardust_frame"]
function stardust:custom_blocks/compute_brightness

