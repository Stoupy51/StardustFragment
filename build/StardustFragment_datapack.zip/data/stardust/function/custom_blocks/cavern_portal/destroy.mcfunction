
#> stardust:custom_blocks/cavern_portal/destroy
#
# @executed	at @s
#
# @within	stardust:custom_blocks/no_block_below
#			stardust:custom_blocks/_groups/minecraft_cobbled_deepslate
#

# Datapack Energy
function energy:v1/api/break_machine


# Replace the item with the custom one
execute as @n[type=item,nbt={Item:{id:"minecraft:cobbled_deepslate"}},distance=..1] run function stardust:custom_blocks/cavern_portal/replace_item

# Decrease count scores
scoreboard players remove #total_custom_blocks stardust.data 1
scoreboard players remove #total_vanilla_cobbled_deepslate stardust.data 1
scoreboard players remove #total_cavern_portal stardust.data 1

# Kill the custom block entity
kill @s

# Decrease the number of entities with second tag
scoreboard players remove #second_entities stardust.data 1

