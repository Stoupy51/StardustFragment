
#> stardust:custom_blocks/cobblestone_miner_lv3/place_secondary
#
# @executed	at @s
#
# @within	stardust:custom_blocks/cobblestone_miner_lv3/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add stardust.custom_block
tag @s add stardust.cobblestone_miner_lv3
tag @s add stardust.vanilla.minecraft_cobbled_deepslate

# Add a custom name
data merge entity @s {"CustomName": [{"translate": "stardust.cobblestone_miner_lv","fallback": "Cobblestone Miner Lv"}, ".3"]}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="stardust:cobblestone_miner_lv3"]
function stardust:custom_blocks/compute_brightness

# Add tag for loop every minute
tag @s add stardust.minute
scoreboard players add #minute_entities stardust.data 1

