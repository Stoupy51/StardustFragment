
#> stardust:custom_blocks/ender_stardust_ore/place_secondary
#
# @executed	at @s
#
# @within	stardust:custom_blocks/ender_stardust_ore/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add stardust.custom_block
tag @s add stardust.ender_stardust_ore
tag @s add stardust.vanilla.minecraft_polished_deepslate

# Add a custom name
data merge entity @s {"CustomName": {"translate": "stardust.ender_stardust_ore","fallback": "Ender Stardust Ore"}}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="stardust:ender_stardust_ore"]
function stardust:custom_blocks/compute_brightness

