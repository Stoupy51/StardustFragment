
#> stardust:custom_blocks/solarium_solar_panel/place_main
#
# @within	stardust:custom_blocks/place
#

tag @s add stardust.placer
setblock ~ ~ ~ air strict
setblock ~ ~ ~ minecraft:daylight_detector
execute align xyz positioned ~0.5 ~0.5 ~0.5 summon item_display at @s run function stardust:custom_blocks/solarium_solar_panel/place_secondary
tag @s remove stardust.placer

# Increment count scores
scoreboard players add #total_custom_blocks stardust.data 1
scoreboard players add #total_vanilla_daylight_detector stardust.data 1
scoreboard players add #total_solarium_solar_panel stardust.data 1

