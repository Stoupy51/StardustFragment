
#> stardust:custom_blocks/stardust_core/place_secondary
#
# @executed	at @s
#
# @within	stardust:custom_blocks/stardust_core/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add stardust.custom_block
tag @s add stardust.stardust_core
tag @s add stardust.vanilla.minecraft_diamond_block

# Add a custom name
data merge entity @s {"CustomName": {"translate": "stardust_core","fallback": "Stardust Core"}}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="stardust:stardust_core"]
function stardust:custom_blocks/compute_brightness

