
#> stardust:custom_blocks/stardust_furnace_generator/destroy
#
# @executed	at @s
#
# @within	stardust:custom_blocks/no_block_below
#			stardust:custom_blocks/_groups/minecraft_furnace
#

# Datapack Energy
function energy:v1/api/break_machine


# Replace the item with the custom one
execute as @n[type=item,nbt={Item:{id:"minecraft:furnace"}},distance=..1] run function stardust:custom_blocks/stardust_furnace_generator/replace_item

# Decrease count scores
scoreboard players remove #total_custom_blocks stardust.data 1
scoreboard players remove #total_vanilla_furnace stardust.data 1
scoreboard players remove #total_stardust_furnace_generator stardust.data 1

# Kill the custom block entity
kill @s

# Decrease the number of entities with second tag
scoreboard players remove #second_entities stardust.data 1

