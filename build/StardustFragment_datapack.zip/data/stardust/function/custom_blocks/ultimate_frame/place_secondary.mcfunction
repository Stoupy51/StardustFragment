
#> stardust:custom_blocks/ultimate_frame/place_secondary
#
# @executed	at @s
#
# @within	stardust:custom_blocks/ultimate_frame/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add stardust.custom_block
tag @s add stardust.ultimate_frame
tag @s add stardust.vanilla.minecraft_crying_obsidian

# Add a custom name
data merge entity @s {"CustomName": [{"text": "U","color": "#ff0000","italic": false},{"text": "l","color": "#ff6d00"},{"text": "t","color": "#ffda00"},{"text": "i","color": "#b6ff00"},{"text": "m","color": "#48ff00"},{"text": "a","color": "#00ff24"},{"text": "t","color": "#00ff91"},{"text": "e","color": "#00ffff"},{"text": " ","color": "#0091ff"},{"text": "F","color": "#0024ff"},{"text": "r","color": "#4800ff"},{"text": "a","color": "#b600ff"},{"text": "m","color": "#ff00da"},{"text": "e","color": "#ff006d"}]}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="stardust:ultimate_frame"]
data modify entity @s transformation.scale set value [1.002f,1.002f,1.002f]
function stardust:custom_blocks/compute_brightness

