
#> stardust:custom_blocks/ultimate_solar_panel/place_secondary
#
# @executed	at @s
#
# @within	stardust:custom_blocks/ultimate_solar_panel/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add stardust.custom_block
tag @s add stardust.ultimate_solar_panel
tag @s add stardust.vanilla.minecraft_daylight_detector

# Add a custom name
data merge entity @s {"CustomName": [{"text": "U","color": "#ff0000","italic": false},{"text": "l","color": "#ff4c00"},{"text": "t","color": "#ff9900"},{"text": "i","color": "#ffe500"},{"text": "m","color": "#ccff00"},{"text": "a","color": "#7fff00"},{"text": "t","color": "#32ff00"},{"text": "e","color": "#00ff19"},{"text": " ","color": "#00ff65"},{"text": "S","color": "#00ffb2"},{"text": "o","color": "#00ffff"},{"text": "l","color": "#00b2ff"},{"text": "a","color": "#0065ff"},{"text": "r","color": "#0019ff"},{"text": " ","color": "#3200ff"},{"text": "P","color": "#7f00ff"},{"text": "a","color": "#cb00ff"},{"text": "n","color": "#ff00e5"},{"text": "e","color": "#ff0098"},{"text": "l","color": "#ff004c"}]}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="stardust:ultimate_solar_panel"]
data modify entity @s transformation.scale set value [1.002f,1.002f,1.002f]
function stardust:custom_blocks/compute_brightness

# Energy part
tag @s add energy.send
scoreboard players set @s stardust.energy_rate 128
scoreboard players set @s energy.max_storage 20000
scoreboard players operation @s energy.transfer_rate = @s energy.max_storage
scoreboard players add @s energy.storage 0
scoreboard players add @s energy.change_rate 0
function energy:v1/api/init_machine

# Fix scale
data modify entity @s transformation.scale[1] set value 1.005f
data modify entity @s transformation.translation[1] set value 0.002f

# Add balancing tag
tag @s add stardust.can_balance

# Add tag for loop every second
tag @s add stardust.second
scoreboard players add #second_entities stardust.data 1

