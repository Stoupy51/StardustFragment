
#> stardust:dimensions/structure/ultimate/part_10
#
# @within	stardust:dimensions/structure/ultimate/part_9 1t [ scheduled ]
#

# Load structure part ultimate_part_-73_48_-69
execute store result score #success stardust.data in stardust:ultimate run place template stardust:ultimate_part_-73_48_-69 -73 48 -69

# If failed, error message and allow a retry on the next check
execute if score #success stardust.data matches 0 run tellraw @a {"translate":"stardust_fragment_the_ultimate_dimension_couldnt_be_built_someth","color":"red"}
execute if score #success stardust.data matches 0 run scoreboard players set #ultimate_building stardust.data 0

# Schedule next part if successful
execute if score #success stardust.data matches 1 run schedule function stardust:dimensions/structure/ultimate/part_11 1t

