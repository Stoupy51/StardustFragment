
#> stardust:forge/verify_structure
#
# @executed	at @s
#
# @within	stardust:forge/second run return fail
#

## Verify Awakened Forge multiblock structure
scoreboard players set #success stardust.data 0

# Structure Orientation
execute if block ~-2 ~-2 ~-2 #minecraft:diamond_ores if block ~-2 ~-1 ~-2 #minecraft:iron_ores if block ~2 ~-2 ~-2 #minecraft:emerald_ores if block ~2 ~-1 ~-2 #minecraft:coal_ores if block ~2 ~-2 ~2 nether_quartz_ore if block ~2 ~-1 ~2 #minecraft:redstone_ores if block ~-2 ~-2 ~2 #minecraft:gold_ores if block ~-2 ~-1 ~2 #minecraft:lapis_ores run scoreboard players set #success stardust.data 1
execute if block ~2 ~-2 ~2 #minecraft:diamond_ores if block ~2 ~-1 ~2 #minecraft:iron_ores if block ~-2 ~-2 ~2 #minecraft:emerald_ores if block ~-2 ~-1 ~2 #minecraft:coal_ores if block ~-2 ~-2 ~-2 nether_quartz_ore if block ~-2 ~-1 ~-2 #minecraft:redstone_ores if block ~2 ~-2 ~-2 #minecraft:gold_ores if block ~2 ~-1 ~-2 #minecraft:lapis_ores run scoreboard players set #success stardust.data 1
execute if block ~2 ~-2 ~-2 #minecraft:diamond_ores if block ~2 ~-1 ~-2 #minecraft:iron_ores if block ~2 ~-2 ~2 #minecraft:emerald_ores if block ~2 ~-1 ~2 #minecraft:coal_ores if block ~-2 ~-2 ~2 nether_quartz_ore if block ~-2 ~-1 ~2 #minecraft:redstone_ores if block ~-2 ~-2 ~-2 #minecraft:gold_ores if block ~-2 ~-1 ~-2 #minecraft:lapis_ores run scoreboard players set #success stardust.data 1
execute if block ~-2 ~-2 ~2 #minecraft:diamond_ores if block ~-2 ~-1 ~2 #minecraft:iron_ores if block ~-2 ~-2 ~-2 #minecraft:emerald_ores if block ~-2 ~-1 ~-2 #minecraft:coal_ores if block ~2 ~-2 ~-2 nether_quartz_ore if block ~2 ~-1 ~-2 #minecraft:redstone_ores if block ~2 ~-2 ~2 #minecraft:gold_ores if block ~2 ~-1 ~2 #minecraft:lapis_ores run scoreboard players set #success stardust.data 1

# Continuation of the structure
execute if score #success stardust.data matches 1 if block ~ ~-1 ~ glass if block ~2 ~ ~2 glass if block ~-2 ~ ~-2 glass if block ~-2 ~ ~2 glass if block ~2 ~ ~-2 glass if block ~ ~-2 ~ diamond_block if block ~1 ~-1 ~1 dragon_egg if block ~-1 ~-1 ~-1 dragon_egg if block ~-1 ~-1 ~1 dragon_egg if block ~1 ~-1 ~-1 dragon_egg if block ~2 ~-2 ~ beacon if block ~ ~-2 ~2 beacon if block ~-2 ~-2 ~ beacon if block ~ ~-2 ~-2 beacon if block ~1 ~-2 ~ red_concrete if block ~-1 ~-2 ~ red_concrete if block ~ ~-2 ~1 red_concrete if block ~ ~-2 ~-1 red_concrete if block ~1 ~-2 ~1 red_concrete if block ~-1 ~-2 ~1 red_concrete if block ~-1 ~-2 ~-1 red_concrete if block ~1 ~-2 ~-1 red_concrete if block ~1 ~-2 ~2 black_concrete if block ~-1 ~-2 ~2 black_concrete if block ~1 ~-2 ~-2 black_concrete if block ~-1 ~-2 ~-2 black_concrete if block ~2 ~-2 ~1 black_concrete if block ~-2 ~-2 ~1 black_concrete if block ~2 ~-2 ~-1 black_concrete if block ~-2 ~-2 ~-1 black_concrete run return 1

# Else, fail
return fail

