
#> stardust:utils/get_all_recipes
#
# @within	(public)
#

# Get all recipes
recipe give @s stardust:stardust_fragment
recipe give @s stardust:dragon_pearl
recipe give @s stardust:compressed_cobblestone
recipe give @s stardust:mirror
recipe give @s stardust:mirror_2
recipe give @s stardust:quarry_configurator
recipe give @s stardust:quarry_lv1
recipe give @s stardust:diamond_seed
recipe give @s stardust:diamond_seed_2
recipe give @s stardust:diamond_seed_3
recipe give @s stardust:diamond_seed_4

