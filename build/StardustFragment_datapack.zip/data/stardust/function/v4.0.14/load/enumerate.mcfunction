
#> stardust:v4.0.14/load/enumerate
#
# @within	#stardust:enumerate
#

# If current major is too low, set it to the current major
execute unless score #stardust.major load.status matches 4.. run scoreboard players set #stardust.major load.status 4

# If current minor is too low, set it to the current minor (only if major is correct)
execute if score #stardust.major load.status matches 4 unless score #stardust.minor load.status matches 0.. run scoreboard players set #stardust.minor load.status 0

# If current patch is too low, set it to the current patch (only if major and minor are correct)
execute if score #stardust.major load.status matches 4 if score #stardust.minor load.status matches 0 unless score #stardust.patch load.status matches 14.. run scoreboard players set #stardust.patch load.status 14

