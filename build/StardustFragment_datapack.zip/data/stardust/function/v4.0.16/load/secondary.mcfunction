
#> stardust:v4.0.16/load/secondary
#
# @within	stardust:v4.0.16/load/main
#

# Stardust Fragment
scoreboard objectives add stardust.data dummy
tag Stoupy51 add convention.debug

# Check dependencies and wait for a player to connect (to get server version)
function stardust:v4.0.16/load/check_dependencies
function stardust:v4.0.16/load/valid_dependencies

