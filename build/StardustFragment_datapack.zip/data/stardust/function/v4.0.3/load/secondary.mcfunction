
#> stardust:v4.0.3/load/secondary
#
# @within	stardust:v4.0.3/load/main
#

# StardustFragment
scoreboard objectives add stardust.data dummy
tag Stoupy51 add convention.debug

# Check dependencies and wait for a player to connect (to get server version)
function stardust:v4.0.3/load/check_dependencies
function stardust:v4.0.3/load/valid_dependencies

