# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

# resolve collision using the on_collision callback (ensure the velocity vector is in canonical space for simpler transformation)
function bs.move:collision/resolve/toi
execute rotated as @s run function #bs.move:local_to_canonical
$$(on_collision)
execute store result storage bs:ctx y int 1 run scoreboard players get $move.hit_flag bs.lambda
function bs.move:collision/resolve/vel with storage bs:ctx
execute rotated as @s run function #bs.move:canonical_to_local
