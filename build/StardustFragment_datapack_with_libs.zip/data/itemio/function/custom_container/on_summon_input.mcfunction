
# @template itemio:custom_container
# @timeout 999999

tag @s add itemio.container
tag @s add itemio.container.hopper
data modify entity @s data.itemio.ioconfig set value [{Slot: 12b, mode: "input", allowed_side: {north: 1b, south: 1b, east: 1b, west: 1b, top: 1b, bottom: 1b}, filters: [{id: ["minecraft:oak_planks"]}]}, {Slot: 14b, mode: "input", allowed_side: {north: 1b, south: 1b, east: 1b, west: 1b, top: 1b, bottom: 1b}, filters: [{id: ["minecraft:oak_planks"]}]}]

function #itemio:calls/container/init
