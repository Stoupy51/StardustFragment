
execute if entity @s[tag=!itemio.network.already_regenerated] run function itemio:v1.8.1/cable/destroy/regen
