# @public

execute if entity @s[tag=smithed.crafter] run function smithed.crafter:v0.8.1/block/table/tick
