execute if score #smithed.crafter.patch load.status matches ..1 unless score #smithed.crafter.patch load.status matches 1 run function smithed.crafter:v0.8.1/technical/load/enumerate/set_version
