
#> stardust:custom_blocks/celestial_portal/second
#
# @executed	as @e[tag=stardust.second] & at @s
#
# @within	stardust:custom_blocks/second
#

# Energy checks
execute if score @s[tag=!stardust.infinite_energy] energy.storage < @s stardust.energy_rate run return 0
scoreboard players operation @s[tag=!stardust.infinite_energy] energy.storage -= @s stardust.energy_rate

# Particles
particle firework ~ ~2 ~ 0.25 1 0.25 0.05 5

# If there is a player standing on the portal, handle it
scoreboard players set #teleporting stardust.data 0
execute positioned ~ ~1 ~ as @a[distance=..1] at @s run function stardust:dimensions/portals/handle_player {"portal":"celestial_portal"}
execute if score #teleporting stardust.data matches 1 if dimension minecraft:overworld in stardust:celestial run forceload add ~-50 ~-50 ~50 ~50
execute if score #teleporting stardust.data matches 1 if dimension stardust:celestial in minecraft:overworld run forceload add ~-50 ~-50 ~50 ~50

