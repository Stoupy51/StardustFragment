
#> stardust:custom_blocks/cobblestone_miner_lv6/place_main
#
# @within	stardust:custom_blocks/place
#

tag @s add stardust.placer
setblock ~ ~ ~ air strict
setblock ~ ~ ~ minecraft:cobbled_deepslate
execute align xyz positioned ~0.5 ~0.5 ~0.5 summon item_display at @s run function stardust:custom_blocks/cobblestone_miner_lv6/place_secondary
tag @s remove stardust.placer

# Increment count scores
scoreboard players add #total_custom_blocks stardust.data 1
scoreboard players add #total_vanilla_cobbled_deepslate stardust.data 1
scoreboard players add #total_cobblestone_miner_lv6 stardust.data 1

