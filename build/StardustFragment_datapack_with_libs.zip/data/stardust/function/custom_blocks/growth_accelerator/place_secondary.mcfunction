
#> stardust:custom_blocks/growth_accelerator/place_secondary
#
# @executed	at @s
#
# @within	stardust:custom_blocks/growth_accelerator/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add stardust.custom_block
tag @s add stardust.growth_accelerator
tag @s add stardust.vanilla.minecraft_diamond_block

# Add a custom name
data merge entity @s {"CustomName": {"translate": "stardust.growth_accelerator"}}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="stardust:growth_accelerator"]
data modify entity @s transformation.scale set value [1.002f,1.002f,1.002f]
function stardust:custom_blocks/compute_brightness

# Energy part
tag @s add energy.receive
scoreboard players set @s stardust.energy_rate 100
scoreboard players set @s energy.max_storage 12000
scoreboard players operation @s energy.transfer_rate = @s energy.max_storage
scoreboard players add @s energy.storage 0
scoreboard players add @s energy.change_rate 0
function energy:v1/api/init_machine

# Add tag for loop every second_5
tag @s add stardust.second_5
scoreboard players add #second_5_entities stardust.data 1

